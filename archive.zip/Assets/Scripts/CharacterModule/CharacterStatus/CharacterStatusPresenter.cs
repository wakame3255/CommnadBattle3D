using System;

public class CharacterStatusPresenter : IBinder
{

    public void Bind()
    {
        throw new NotImplementedException();
    }
}