using System;
using UnityEngine;

public class CharacterStatusView : MonoBehaviour, IInitialize
{
    public void Initialize()
    {
        throw new NotImplementedException();
    }
}
