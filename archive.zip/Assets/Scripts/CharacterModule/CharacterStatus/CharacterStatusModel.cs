using System;

public class CharacterStatusModel : IInitialize
{

    public void Initialize()
    {
        throw new NotImplementedException();
    }
}