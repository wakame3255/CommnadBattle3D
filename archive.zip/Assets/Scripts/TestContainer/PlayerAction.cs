
public class PlayerAction
{
  public PlayerAction()
    {
        DebugUtility.Log("PlayerAction Constructor");
    }
}
