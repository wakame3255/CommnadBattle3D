

using System.Diagnostics;

public class PlayerStatus
{
   public PlayerStatus()
    {
        DebugUtility.Log("PlayerStatus Constructor");
    }
}
