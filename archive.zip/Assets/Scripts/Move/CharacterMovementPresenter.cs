using System;

public class CharacterMovementPresenter
{

}