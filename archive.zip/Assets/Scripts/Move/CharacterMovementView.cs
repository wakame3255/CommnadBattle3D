using System;

public class CharacterMovementView
{

}