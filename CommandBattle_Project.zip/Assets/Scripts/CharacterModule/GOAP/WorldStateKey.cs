using System;

public enum WorldStateKey
{
    EnemyIsInRange,
}
