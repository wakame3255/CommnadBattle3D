using System;

public interface IDamageNotice
{

    public void NotifyDamage(int damage);
}