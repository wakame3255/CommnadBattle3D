using System;
using UnityEngine;
using UnityEngine.UI;
using R3;

public class MeleeAttackView : ActionViewBase, IInitialize
{
    //行動画像やアニメーション
}