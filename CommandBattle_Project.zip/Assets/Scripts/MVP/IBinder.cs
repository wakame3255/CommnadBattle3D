using System;

public interface IBinder
{
    /// <summary>
    /// モデルとビューをバインドする
    /// </summary>
    public void Bind();
}