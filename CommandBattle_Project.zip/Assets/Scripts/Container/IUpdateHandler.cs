using System;

public interface IUpdateHandler
{
    /// <summary>
    /// 更新処理メソッド
    /// </summary>
    public void Updateable();
}
